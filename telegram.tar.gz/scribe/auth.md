# Authenticating requests

This API is not authenticated.
