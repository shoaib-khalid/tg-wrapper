<?php if($authenticated): ?><?php $__env->startComponent('scribe::components.badges.base', ['colour' => "darkred", 'text' => 'requires authentication']); ?>
<?php if (isset($__componentOriginala0bd2d4220206a695a9c7273366f88cdebe75a9f)): ?>
<?php $component = $__componentOriginala0bd2d4220206a695a9c7273366f88cdebe75a9f; ?>
<?php unset($__componentOriginala0bd2d4220206a695a9c7273366f88cdebe75a9f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Dell-Admin\Documents\Projects\wrappers\tg-wrapper\vendor\knuckleswtf\scribe\src/../resources/views//components/badges/auth.blade.php ENDPATH**/ ?>