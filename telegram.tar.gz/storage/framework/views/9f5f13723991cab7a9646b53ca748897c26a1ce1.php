<?php
    /** @var  Knuckles\Camel\Output\OutputEndpointData $endpoint */
?>

<h2 id="<?php echo Str::slug($group['name']); ?>-<?php echo $endpoint->endpointId(); ?>"><?php echo e($endpoint->metadata->title ?: ($endpoint->httpMethods[0]." ".$endpoint->uri)); ?></h2>

<p>
<?php $__env->startComponent('scribe::components.badges.auth', ['authenticated' => $endpoint->metadata->authenticated]); ?>
<?php if (isset($__componentOriginal1e3c925ac55727563f8ad4b989338496bcdbada8)): ?>
<?php $component = $__componentOriginal1e3c925ac55727563f8ad4b989338496bcdbada8; ?>
<?php unset($__componentOriginal1e3c925ac55727563f8ad4b989338496bcdbada8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</p>

<?php echo Parsedown::instance()->text($endpoint->metadata->description ?: ''); ?>


<blockquote>Example request:</blockquote>

<?php $__currentLoopData = $metadata['example_languages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make("scribe::partials.example-requests.$language", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($endpoint->isGet() || $endpoint->hasResponses()): ?>
    <?php $__currentLoopData = $endpoint->responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <blockquote>
            <p>Example response (<?php echo e($response->description ?: $response->status); ?>):</p>
        </blockquote>
        <?php if(count($response->headers)): ?>
        <details class="annotation">
            <summary>
                <small onclick="textContent = parentElement.parentElement.open ? 'Show headers' : 'Hide headers'">Show headers</small>
            </summary>
            <pre>
            <code class="language-http"><?php $__currentLoopData = $response->headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($header); ?>: <?php echo e(is_array($value) ? implode('; ', $value) : $value); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </code>
            </pre>
        </details> <?php endif; ?>
        <pre>
                <code class="language-json">
<?php if(is_string($response->content) && Str::startsWith($response->content, "<<binary>>")): ?>
[Binary data] - <?php echo e(htmlentities(str_replace("<<binary>>", "", $response->content))); ?>

<?php elseif($response->status == 204): ?>
[Empty response]
<?php else: ?>
<?php ($parsed = json_decode($response->content)); ?>

<?php echo htmlentities($parsed != null ? json_encode($parsed, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) : $response->content); ?>

<?php endif; ?> </code>
        </pre>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div id="execution-results-<?php echo e($endpoint->endpointId()); ?>" hidden>
    <blockquote>Received response<span
                id="execution-response-status-<?php echo e($endpoint->endpointId()); ?>"></span>:
    </blockquote>
    <pre class="json"><code id="execution-response-content-<?php echo e($endpoint->endpointId()); ?>"></code></pre>
</div>
<div id="execution-error-<?php echo e($endpoint->endpointId()); ?>" hidden>
    <blockquote>Request failed with error:</blockquote>
    <pre><code id="execution-error-message-<?php echo e($endpoint->endpointId()); ?>"></code></pre>
</div>
<form id="form-<?php echo e($endpoint->endpointId()); ?>" data-method="<?php echo e($endpoint->httpMethods[0]); ?>"
      data-path="<?php echo e($endpoint->uri); ?>"
      data-authed="<?php echo e($endpoint->metadata->authenticated ? 1 : 0); ?>"
      data-hasfiles="<?php echo e($endpoint->hasFiles() ? 1 : 0); ?>"
      data-headers='<?php echo json_encode($endpoint->headers, 15, 512) ?>'
      onsubmit="event.preventDefault(); executeTryOut('<?php echo e($endpoint->endpointId()); ?>', this);">
    <h3>
        Request&nbsp;&nbsp;&nbsp;
        <?php if($metadata['try_it_out']['enabled'] ?? false): ?>
            <button type="button"
                    style="background-color: #8fbcd4; padding: 5px 10px; border-radius: 5px; border-width: thin;"
                    id="btn-tryout-<?php echo e($endpoint->endpointId()); ?>"
                    onclick="tryItOut('<?php echo e($endpoint->endpointId()); ?>');">Try it out ⚡
            </button>
            <button type="button"
                    style="background-color: #c97a7e; padding: 5px 10px; border-radius: 5px; border-width: thin;"
                    id="btn-canceltryout-<?php echo e($endpoint->endpointId()); ?>"
                    onclick="cancelTryOut('<?php echo e($endpoint->endpointId()); ?>');" hidden>Cancel
            </button>&nbsp;&nbsp;
            <button type="submit"
                    style="background-color: #6ac174; padding: 5px 10px; border-radius: 5px; border-width: thin;"
                    id="btn-executetryout-<?php echo e($endpoint->endpointId()); ?>" hidden>Send Request 💥
            </button>
        <?php endif; ?>
    </h3>
    <?php $__currentLoopData = $endpoint->httpMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>
            <?php $__env->startComponent('scribe::components.badges.http-method', ['method' => $method]); ?><?php if (isset($__componentOriginal987bd53b91ff4b32d3b3e321f5d1e4e9c25b0418)): ?>
<?php $component = $__componentOriginal987bd53b91ff4b32d3b3e321f5d1e4e9c25b0418; ?>
<?php unset($__componentOriginal987bd53b91ff4b32d3b3e321f5d1e4e9c25b0418); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            <b><code><?php echo e($endpoint->uri); ?></code></b>
        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($endpoint->metadata->authenticated && $metadata['auth']['location'] === 'header'): ?>
        <p>
            <label id="auth-<?php echo e($endpoint->endpointId()); ?>" hidden><?php echo e($metadata['auth']['name']); ?> header:
                <b><code><?php echo e($metadata['auth']['prefix']); ?></code></b><input type="text"
                                                                name="<?php echo e($metadata['auth']['name']); ?>"
                                                                data-prefix="<?php echo e($metadata['auth']['prefix']); ?>"
                                                                data-endpoint="<?php echo e($endpoint->endpointId()); ?>"
                                                                data-component="header"></label>
        </p>
    <?php endif; ?>
    <?php if(count($endpoint->urlParameters)): ?>
        <h4 class="fancy-heading-panel"><b>URL Parameters</b></h4>
        <?php $__currentLoopData = $endpoint->urlParameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>
                <?php $__env->startComponent('scribe::components.field-details', [
                  'name' => $parameter->name,
                  'type' => $parameter->type ?? 'string',
                  'required' => $parameter->required,
                  'description' => $parameter->description,
                  'endpointId' => $endpoint->endpointId(),
                  'component' => 'url',
                ]); ?>
                <?php if (isset($__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e)): ?>
<?php $component = $__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e; ?>
<?php unset($__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(count($endpoint->queryParameters)): ?>
        <h4 class="fancy-heading-panel"><b>Query Parameters</b></h4>
        <?php $__currentLoopData = $endpoint->queryParameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute => $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>
                <?php $__env->startComponent('scribe::components.field-details', [
                  'name' => $parameter->name,
                  'type' => $parameter->type,
                  'required' => $parameter->required,
                  'description' => $parameter->description,
                  'endpointId' => $endpoint->endpointId(),
                  'component' => 'query',
                ]); ?>
                <?php if (isset($__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e)): ?>
<?php $component = $__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e; ?>
<?php unset($__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(count($endpoint->nestedBodyParameters)): ?>
        <h4 class="fancy-heading-panel"><b>Body Parameters</b></h4>
        <?php $__env->startComponent('scribe::components.body-parameters', ['parameters' => $endpoint->nestedBodyParameters, 'endpointId' => $endpoint->endpointId(),]); ?>
        <?php if (isset($__componentOriginalb43036a1322e744ae294c083663901316ee4e16e)): ?>
<?php $component = $__componentOriginalb43036a1322e744ae294c083663901316ee4e16e; ?>
<?php unset($__componentOriginalb43036a1322e744ae294c083663901316ee4e16e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
</form>

<?php if(count($endpoint->responseFields)): ?>
    <h3>Response</h3>
    <h4 class="fancy-heading-panel"><b>Response Fields</b></h4>
    <?php $__currentLoopData = $endpoint->responseFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>
            <?php $__env->startComponent('scribe::components.field-details', [
              'name' => $field->name,
              'type' => $field->type,
              'required' => true,
              'description' => $field->description,
              'isInput' => false,
            ]); ?>
            <?php if (isset($__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e)): ?>
<?php $component = $__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e; ?>
<?php unset($__componentOriginal673c41eaf58f2b5c66b5a2c7fb01bca581a21e5e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Dell-Admin\Documents\Projects\wrappers\tg-wrapper\vendor\knuckleswtf\scribe\src/../resources/views//themes/default/endpoint.blade.php ENDPATH**/ ?>